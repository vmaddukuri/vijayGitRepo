"""n = 15
print(n)
print(type(n))
print()

print(15)  # various notation of int
print(0xf)
print(0b1111)
print(0o17)
print()

n = 15
print(bin(n))
print(oct(n))
print(hex(n))
print()"""

# to integers
print(int('1111', 2))
print(int('f', 16))
print(int('17', 8))

print(8 / 3)