while -12.21:
    print('@', end='\t')
