print('kim', end='')
print('amanda', end='')
print('eva', end='')
print('tim', end='')
print('tom')  # Output Record Sep

print(1,2,'iii',4.4,5)  # Output Record Sep
print(1,2,'iii',4.4,5, sep=':')  # Output Record Sep

# keyword argument parameter

# string formatting create formatted string,
