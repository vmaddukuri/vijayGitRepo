'''n = 14
result = n ** 2 if n > 5 else n ** 3
print(result)
'''

s = 'this is a sample string in python'

print('sam' in s)
print('s a' in s)
print('zee' not in s)