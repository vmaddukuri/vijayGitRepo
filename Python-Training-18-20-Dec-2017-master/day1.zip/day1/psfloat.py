'''print(0.003)
print(3e-3)

print(3E-3)

# complex number (real, imag)'''

n = 4+3j
print(n)
print(type(n))
print(n.real)
print(n.imag)
print(n.conjugate())
print()
print(n * n)