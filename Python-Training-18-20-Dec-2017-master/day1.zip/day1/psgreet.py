name = 'hp'
city = 'ny'

print('name :', name)
print('city :', city)

