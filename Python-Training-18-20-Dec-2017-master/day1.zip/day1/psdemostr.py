"""s = 'python'
# s[2] = 'T'  #

print(s)
"""

# regular vs raw
"""
file_path = 'c:\templates\neon\balances\rulebook\temp.txt'
print(file_path)
print()
print()

# raw string
file_path = r'c:\templates\neon\balances\rulebook\temp.txt'
print(file_path)
"""

