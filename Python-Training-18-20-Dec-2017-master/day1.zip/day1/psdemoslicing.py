"""
slicing
~~~~~~~
name[start-index:ex-of-end-index:frequency]
"""

s = 'perlandpython'
s2 = s.replace('and', 'aNd')
print(s)
print(s2)

'''print(s[:4])
print(s[3:7])
print(s[-5:])
print(s[:])
print(s[1:-1])
print(s[-6:-4])
'''
print(s[::-1])  #reverse the content of the type sequences.

