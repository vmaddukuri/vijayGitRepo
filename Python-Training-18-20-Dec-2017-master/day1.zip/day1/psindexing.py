"""
indexing
~~~~~~~~
-4  -3  -2  -1  -ve

p   e   r   l

0   1   2   3   +ve

"""

s = 'perl'
"""
print(s[0])
print(s[1])
print(s[2])
print(s[3])
"""
print(s[-1])
print(s[-2])
print(s[-3])
print(s[-4])
