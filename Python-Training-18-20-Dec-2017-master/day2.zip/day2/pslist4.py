items = [2.2, 'pam', 3.3, 1.9, 3.4]

print(items + items)
print(items * 2)
print()

seq = [2.2, 'pam', 3.3, 1.9, 3.4, 2.2, 'pam', 3.3, 1.9, 3.4]
uniq = []

for item in seq:
    if item not in uniq:
        uniq.append(item)

print(uniq)
print()
print(set(seq))
print(list(set(seq)))