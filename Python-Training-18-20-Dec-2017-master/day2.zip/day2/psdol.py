from pprint import pprint as pp

content = {}


for line in open('passwd.txt'):
    user_info = line.rstrip().split(':')
    user_name, shell = user_info[0], user_info[-1]

    # print(user_name, shell)

    if shell not in content:
        content[shell] = []

    content[shell].append(user_name)


for shell, list_of_users in content.items():
    print(shell)
    print("\tusers count :", len(list_of_users))
    print()

    for user_name in sorted(list_of_users):
        print("\t", user_name)

    print()

