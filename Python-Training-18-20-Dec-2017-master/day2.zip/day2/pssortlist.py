items = [2.2, .9, 3.3, 1.9, 3.4, 3.142, 0.812]
items.sort()  # inplace edit
print(items)
print()

items.sort(reverse=True)  # inplace edit, desc order
print(items)
print()

items = [2.2, .9, 3.3, 1.9, 3.4, 3.142, 0.812]
items.reverse()  # inplace edit
print(items)