file_name = 'passwd.txt'

fp = open(file_name, 'r')

while True:
    line = fp.readline()
    if not line:
        break


#for item in fp:
#    print(item, end='')

# print(fp.read(32))
# print(fp.readline())
# print(fp.readlines())
fp.close()