info = {}
print(info)
print(type(info))
print(len(info))
print()

info = {
    'host': 'ws1',
    'domain': 'rootcap.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.2
}
print(info)
# add
# update
# delete
# lookup aka read
# iterate
