s = 'root:x:0:0:root:/root:/bin/bash'
delimiter = ':'

# str-tok
items = s.split(delimiter)
print(items)
print()
print(s.split(delimiter)[0])  # indexing
print()
print(s.split(delimiter)[1:])  # slicing
print()
for item in items:   # iterate
    print(item)

# https://github.com/ravijaya
