names = 'pam', 'eva', 'allen', 'neil'
print(names)
print()

n = (1000)
print(n)

print()

n = (1000,)
print(n)
