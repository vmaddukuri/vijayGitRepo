items = [2.2, 'pam', 'pam', 3.3, 'pam', 1.9, 'pam', 3.4]
item = 'pam'
first_occur_pam = items.index(item)

temp = items[first_occur_pam+1:]
print(temp)
print()

while item in temp:
    temp.remove(item)

print(items[:first_occur_pam + 1] + temp)