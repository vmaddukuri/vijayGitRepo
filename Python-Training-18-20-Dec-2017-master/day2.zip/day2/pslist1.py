items = []
print(items)
print(type(items))
print(len(items))
print()

items = [2.2, 'pam', 'allen', 3.3, 'pip', 1.9, 'cpan', 3.4]
print(items)
print()

items[-4] = 'pypi'  # update
print(items)
print()

items.append('sonic') # append
print(items)
print()

items.insert(0, 'bangalore') # insert
items[2] += 'bangalore'
print(items)
print()