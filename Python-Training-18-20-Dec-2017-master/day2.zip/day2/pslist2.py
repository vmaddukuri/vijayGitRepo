items = [2.2, 'pam', 'allen', 3.3, 'pip', 1.9, 'cpan', 3.4]

# by index
value = items.pop(2)
print(value)
print(items)
print()

# by value
items = [2.2, 'pam', 'pam', 3.3, 'pam', 1.9, 'pam', 3.4]
item = 'pam'
print(items.count(item))

while item in items:
    items.remove(item)

print()
print(items)
