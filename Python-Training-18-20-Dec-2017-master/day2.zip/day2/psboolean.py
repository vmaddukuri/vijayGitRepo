print(bool(''))
print(bool(0))
print(bool(0.0))
print(bool(0+0j))
print(bool([]))  # list
print(bool(()))  # tuple
print(bool({}))  # dict
print(bool(set())) # set
print(bool(None))
print(type(None))