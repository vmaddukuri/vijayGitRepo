items = ('2.2', 2.2, 2, 'eva', 'tim', 'tom', 'jeo')
print(items)
print(type(items))

# items[-3] = 'timmy'
print(items[-3])
print(items[:-3])
print()

for item in items:
    print(item)