items = [2.2, 'pam', 3.3, 1.9, 3.4]
vow = ['pip', 'easy', 'yaml']
items.append(vow)

print(items)

'''
print(items + vow)
print(items)
print()

items.extend(vow)
print(items)
print()

items.extend('peter')
print(items)
'''