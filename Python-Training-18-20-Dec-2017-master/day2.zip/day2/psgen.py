
items = (hex(item) for item in range(10))
print(items)
print(type(items))

for item in items:
    print(item)

