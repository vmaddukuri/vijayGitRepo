items = ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']



# iterate list item for its (index, value)
for temp1, temp2 in enumerate(items):
    print(temp1, '->', temp2)


