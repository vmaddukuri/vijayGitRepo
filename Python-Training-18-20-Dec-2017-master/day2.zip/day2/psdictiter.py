info = {
    'host': 'ws1',
    'domain': 'rootcap.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.3
}
"""
# lookup aka read
print(info['host'])
print(info['domain'])
print(info.get('app'))
print(info.get('apps'))
print(info.get('apps', 'unknown-key'))
"""

print(info.keys())
print(info.values())
print(info.items())  # key, vlaue pair each element

