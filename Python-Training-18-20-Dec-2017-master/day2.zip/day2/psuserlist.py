"""a demo for the list"""


def get_user_list(data_file, target_file):
    """
    get's the list of users
    :param data_file: str
    :param target_file: str
    :return:
    """
    list_of_users = []

    try:
        for line in open(data_file):
            login = line.split(':')[0]
            list_of_users.append(login)

        list_of_users.sort()

        with open(target_file, 'w') as fw:  # context manager
            for line_no, user in enumerate(list_of_users, 1):
                formatted_content = "{:>6}  {}".format(line_no, user)
                print(formatted_content)
                fw.write(formatted_content + "\n")

    except (FileNotFoundError, IOError) as err:
        print(err)

file_name = input('enter the filename :')
get_user_list(file_name, 'passwd.dat')
