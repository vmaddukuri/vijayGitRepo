info = {
    'host': 'ws1',
    'domain': 'rootcap.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': None,
    None: None
}

item = 'version'

if item in info:  # validate for the key
    info[item] = 3.6 # update

print(info)
print()

info['arch'] = 'x86_64'  # adding an element
print(info)
print()

print('deleting an element from the dict :')
value = info.pop('desc')
print(value)
print(info)
# add
# update
# delete
# lookup aka read
# iterate
