info = {
    'host': 'ws1',
    'domain': 'rootcap.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.3
}

#for item in info:
#    print(item, ':', info[item])

for key, vlaue in info.items():
    print(key, '->', vlaue)
