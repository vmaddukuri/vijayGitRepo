items1 = [1, 2, 3, 'jim', 5, 6]
items2 = ['jim', 3, 5, 7, 9]


x = set(items1)
y = set(items2)
print(x.intersection(y))
print(list(x.intersection(y)))
print()
print(x.union(y))
print()
print(x.difference(y))
print(y - x)
