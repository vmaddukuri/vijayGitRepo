info = {
    'host': 'ws1',
    'domain': 'rootcap.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': None,
}

print('Available keys :')
for item in info:
    print("\t", item)

try:
    item_key = input('Choice to delete :')
    info.pop(item_key)
    print()
    print(info)
except KeyError as err:
    print(err)