#To make packages distributable

from distutils.core import setup
#"disutils:Distrubuted utilities"

setup(name='processmanager',
      version=1.0,
      packages=['processmanager'])