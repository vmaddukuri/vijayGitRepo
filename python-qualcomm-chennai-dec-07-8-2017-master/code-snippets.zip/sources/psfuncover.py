

def demo(*args):
    print(len(args))


demo(12,434)

print(range())
print(list(range(10)))
print(list(range(1, 10)))
print(list(range(1, 10, 2)))