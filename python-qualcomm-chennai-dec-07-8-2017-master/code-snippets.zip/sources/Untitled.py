
# coding: utf-8

# In[1]:


print(dir(str))


# In[2]:


n = 15
print(n)
print(type(n))


# In[8]:


print(0xf)
print(0o17)
print(0b1111)
print(15)

n = 0o17
n += 1
print(n)
print(type(n))


# In[5]:


n = 15
print(hex(n))
print(bin(n))
print(oct(n))


# In[6]:


print(int('f', 16))
print(int('17', 8))
print(int('1111', 2))
print(int('15'))


# In[9]:


8 / 3


# In[11]:


print(0.003)
print(3e-3)


# In[16]:


n = 4 + 3j
print(n)
print(type(n))
print(n.real)
print(n.imag)
print(n.conjugate())
print()
print(n ** n)
print(3 **3)


# In[19]:


s = 'python'  # immutable object 
# s[2] = 'T'
print(s[2])


# In[22]:


# regular vs raw string 
path = "c:\templates\folder99\rules\neon\balances\temp.txt"
print(path)


# In[23]:


# raw string

path = r"c:\templates\folder99\rules\neon\balances\temp.txt"
print(path)


# In[26]:


# doc string, multiline formatted content

s = """
   1
  2 2
 3 {} 3
  4 4
   5
"""
print(s.format('x'))


# In[31]:


#  byte string
from subprocess import check_output


# op = check_output('ipconfig')  # windows
op = check_output('ifconfig')
# help(type(op))

print(op.decode('ascii'))  # byte string to unicode


# In[33]:


s = 'peter'
print(type(s))

s = b'peter'
print(type(s))


# In[34]:


s = b'peter'  # byte string to unicode 
print(s.decode('ascii'))


# In[36]:


s = 'peter'  # unicode to byte string
s.encode('ascii')


# In[38]:


# sequence operations 
# indexing

s = 'perl'

print(s[0])
print(s[1])
print(s[2])
print(s[3])


# In[41]:


s = 'perl'  # -ve 
print(s[-1])
print(s[-2])
print(s[-3])
print(s[-4])


# In[51]:


s = 'perlandpython'
print(s[:4])
print(s[3:7])
print(s[-6:])
print(s[:])
print(s[1:-1])
print(s[-6:-4])
print(len(s[-4:-6]))


# In[52]:


print(ord('A'))
print(chr(65))


# In[58]:


s = 'this is a sample string in python'

print(enumerate(s))
print()
for index, value in enumerate(s):
    print("[{}] -> {}".format(index, value))
    
#for item in enumerate(s):
#    print(item)


# In[68]:


s = '''root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
adm:x:3:4:adm:/var/adm:/sbin/nologin
lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin
sync:x:5:0:sync:/sbin:/bin/sync
shutdown:x:6:0:shutdown:/sbin:/sbin/shutdown
halt:x:7:0:halt:/sbin:/sbin/halt
mail:x:8:12:mail:/var/spool/mail:/sbin/nologin
operator:x:11:0:operator:/root:/sbin/nologin'''
items = s.split('\n')
print(items)
print()
for index, item in enumerate(items):
    print(index, '->', item)


# In[74]:


s = 'root:x:0:0:root:/root:/bin/bash'

print('oo' in s) 
print('bash' in s)

items = [1, 3 ,2, 4, 8 ,5 ]
print(3 in items)
print(33 not in items)
print('zeal' not in items)


# In[78]:


# ident operator
# is , is not 
items = [1, 3, 2.2, 4, 'x',  8, 5, 'vii']

for item in items:
    if type(item) is int:
        print(item ** 2)
    elif type(item) is str:
        print(item.upper())
    else:
        print(item)


# In[80]:


"""if else conditional operator(? :)
--------------------------------
syntax: -

true-part-expression if test-condition else false-part-expr
"""

n = 14
result = n **  2 if n > 5 else n ** 3
print(result)


# In[81]:


# short hand assign  += , -=, *=, /=, **= %= 
n = 5
n %= 2
n


# In[83]:


1 != 1


# In[85]:


n = 5.5 
n >= 3 and n <= 7
3 <= n <= 7


# In[87]:


bool('')


# In[88]:


bool(-12.21)


# In[95]:


# list of literals that gives you boolean false 
print(bool(''))
print(bool(0))
print(bool(0.0))
print(bool(0+0j))
print(bool([]))  # list
print(bool(()))  # tuple
print(bool({}))  # dict 
print(bool(set()))  # set 
print(bool(None))  
print(type(None))  


# In[98]:


s = 'root:x:bin:0:root:/root:/bin/bash'
s.replace('bin', '') + "bin"


# In[100]:


# list aka array ordered collections 

items = [] # list()
print(items)
print(len(items))
print(type(items))


# In[103]:


items = [2.2, 'pam', 3.4, 'iii', 4, 13, 2 ,1]
items[-3] *= 2
items.append('qualcomm')
items.insert(0, 'madras')
print(items)


# In[105]:


items = ['madras', 2.2, 'pam', 3.4, 'iii', 4, 26, 2, 1, 'qualcomm']
# delete by index
value = items.pop(-6)
print(value)
print()
print(items)


# In[107]:


# delete by value
items = ['pam', 2.2, 'pam', 3.4, 'pam', 26, 2, 1, 'pam']
item = 'pam'
items.count(item)


# In[110]:


items = ['pam', 2.2, 'pam', 3.4, 'pam', 26, 2, 1, 'pam']
item = 'pam'
items.remove(item)
print(items)
#help(items.remove)


# In[111]:


items = ['pam', 2.2, 'pam', 3.4, 'pam', 26, 2, 1, 'pam']
item = 'pam'

while item in items:
    items.remove(item)
    
print(items)


# In[113]:


print([2.2, 3.4, 26, 2, 1] + [2.2, 3.4, 26, 2, 1])
print([2.2, 3.4, 26, 2, 1] * 2)


# In[115]:


items = [2.2, 3.4, 26, 2, 1, 2.2, 3.4, 26, 2, 1]
temp = list()

for item in items:
    if item not in temp:
        temp.append(item)
        
print(temp)


# In[123]:


items = [2.0, 3.4, 'peter', '2', 2, 1, 2.2, 3.4, 26, 'peter', 1]
print(set(items))
print()
print(list(set(items)))  # set aka hashed list = hash + array 


# In[124]:


items = [2.2, 3.4, 26, 2, 1, 2.2, 3.4, 26, 2, 1]
items.reverse()  # inplace edit 

print(items)


# In[127]:


items = [2.2, 3.4, 26, 2, 1, 2.2, 3.4, 26, 2, 1]
items.sort(reverse=True)  # inplace edit 

print(items)
print(items[:3])
print(items[-3:])


# In[128]:


items = [2.2, 3.4, 26, 2, 1, 2.2, 3.4, 26, 2, 1]
print(max(items))
print(min(items))
print(sum(items))


# In[133]:


s = 'root:x:0:0:root:/root:/bin/bash'
items = s.split(':')
print(items)
print()
print(s.split(':')[0])
print()
print(s.split(':')[1:])
print()

#
items = ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']
delimiter = ';'
s2 = delimiter.join(items)
print(s2)


# In[137]:


lang = ['perl', 'python', 'ruby']
author = ['wall', 'guido']
release = ['5.28', '3.6.3', '2.18']
items = list(zip(lang, author, release))

print(items)
for item in zip(lang, author, release):
    print(item)


# In[139]:


# dict aka hash-map, key => value, unordered collections 
# looup db, O(n),  O(1) 

info = dict() # {}
print(info)
print(len(info))
print(type(info))


# In[141]:


info = {
    'host': 'ws1',
    'domain': 'rootcapo.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.2
}
print(info)


# In[ ]:


# ADD
# delete
# update
# lookup aka read
# iteration


# In[148]:


info = {
    'host': 'ws1',
    'domain': 'rootcapo.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.2
}

item = 'version'

if item in info: # validate for the key
    info[item] = 3.6 # update

print(info)
print()
info['arch'] = None # add 
print(info)
print()
value = info.pop('desc')# delete
print(value)
print()
print(info)


# In[156]:


info = {
    'host': 'ws1',
    'domain': 'rootcapo.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.2
}

# info.popitem()
# lookup

print(info['host'])
print(info['domain'])
print(info.get('app'))
print(info.get('apps'))
print(info.get('app', 'unknown-key'))  # get(key, default-value)


# In[157]:


info = {
    'host': 'ws1',
    'domain': 'rootcapo.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.2
}

print(info.keys())
print()
print(info.values())
print()
print(info.items())


# In[165]:


info = {
    'host': 'ws1',
    'domain': 'rootcapo.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.2
}

# iterations 

#for item in sorted(info):   # inorder of keys
#for item in info:
#    print(item, ':', info[item])

for k, v in info.items():
    print(k, '->', v)


# In[160]:


items = [2.2 ,1, 3, 4 ,2 ,5 ,6 ,7 ,1 ]

items.sort()  # inplace edit 
print(items)


# In[161]:


items = [2.2 ,1, 3, 4 ,2 ,5 ,6 ,7 ,1 ]
s = sorted(items)
print(s)
print()
print(items)


# In[ ]:


# d1, d2, d3

{
    'd1': {
        'f1': [size, mtime],
        'f2': [size, mtime]
    }, 
    'd2': {
        'g1': [size, ,time],....
    }.....
}

# serialize into a json 


# In[167]:


items = [1, 2 ,3 ,4]
temp = list()

for item in items:
    temp.append(bin(item))
    
print(temp)


# In[168]:


# list comp. 
items = [1, 2 ,3 ,4]
temp2 = [bin(item) for item in items]
print(temp2)


# In[170]:


items = [1, 2 ,3 ,4, 5, 4 ,3 ,5]
temp3 = [item ** 2 for item in items if item %2]
print(temp3)


# In[179]:


a = [1, 2, 3, 4 ,5 ,6 ,8 ,9]
b = [1, 3, 7 ,9]

x = set(a)
y = set(b)

print(x.intersection(y))
print(list(x.intersection(y)))
print(x & y)
print()

print(x.union(y))
print(x | y)
print()
print(x.difference(y))
print(y - x)


# In[181]:


[oct(item) for item in range(1, 10)]  # list comp


# In[182]:


{item: oct(item) for item in range(1, 10)}  # dict comp 


# In[184]:


{oct(item) for item in range(1, 10) if item % 2}  # set comp 


# In[185]:


# regex 
#1. match
#2. sub
#3. split 


# In[192]:


import re

s = 'the python and the perl scripting'
pattern = 'P.+?N'  # non-greedy 

m = re.search(pattern, s, re.I)
print('match string :', m.group()) 
before = s[:m.start()]
after = s[m.end():]
print("before : |{}|".format(before))
print("after : |{}|".format(after))


# In[199]:


# multi match  # word broundary 
import re

s = 'the python and the perl scripting peagon'
pattern = r'\bP[a-zA-Z0-9]+?N\b'

for m in re.finditer(pattern, s, re.I):
    print(m.group())
    print(m.span())
    print()
    
# list of match string 
print(re.findall(pattern, s, re.I))


# In[204]:


import re

s = 'root;x:0;0 root;/root;/bin/bash'
pattern = ';|:| '
replacement = ','

s2 = re.sub(pattern, replacement, s, count=1)
print(s2)


# In[203]:


import re
pattern = [';', ' ']
replacement = ['.', '*']

s = 'root;x:0;0 root;/root;/bin/bash'

for pat, repl in zip(pattern, replacement):
    s = re.sub(pat, repl, s)
    print(s)
    
print()
print(s)


# In[205]:


import re

s = 'root;x:0;0 root;/root;/bin/bash'

items = re.split('[;: ]', s)
print(items)


# In[209]:


import re

s = '12/08/17'

pattern = '(\d\d)/(\d\d)/(\d\d)'
m = re.search(pattern, s)

print(m.group())
print(m.group(1))
print(m.group(2))
print(m.group(3))
print(m.groups())




# In[211]:


def compute(a, b, c):
    print(a + b + c)
    
items = (11, 22, 33)

compute(items[0], items[1], items[2])
compute(*items)

