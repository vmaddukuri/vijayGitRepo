import paramiko


def custom_ssh_client(hostname, port=22, user=None, passwd=None):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname, port, user, passwd)

    stdin, stdout, stderr = ssh.exec_command('df -h')
    temp = stdout.read()
    ssh.close()
    return temp.decode('ascii')


op = custom_ssh_client('127.0.0.1', user='training', passwd='training')
print(op)
