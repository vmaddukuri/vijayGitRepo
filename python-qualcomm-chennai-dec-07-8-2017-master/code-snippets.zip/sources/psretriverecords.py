import sqlite3
from pprint import pprint as pp


class SQLiteClient:
    def __init__(self, db_name):
        """constructor"""
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()

    def select_records(self):
        query = 'select * from passwd'
        self.cursor.execute(query)
        column_header = [header_info[0] for header_info in self.cursor.description]

        for user in self.cursor.fetchall():
            for caption, value in zip(column_header, user):
                print("{:>16} : {}".format(caption, value))
            print()

    def __del__(self):
        """destructor"""
        self.conn.close()


db = SQLiteClient('dec08.sqlite')
db.select_records()
