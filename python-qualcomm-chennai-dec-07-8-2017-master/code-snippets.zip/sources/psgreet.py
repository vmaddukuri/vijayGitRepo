name = 'qualcomm'
city = 'chennai'

print('name :', name)
print('city :', city)
