from glob import glob
from psmakearchive import create_zip, extract_zip

create_zip('pysources.zip', *glob('*.py'))

extract_zip('pysources.zip', '/tmp/src')

# pypi.python.org
# paramiko

#

""" def demo(*args):
    print(args)

demo(glob('pass*'))
demo(*glob('pass*')) """ # passing the content of the seq
