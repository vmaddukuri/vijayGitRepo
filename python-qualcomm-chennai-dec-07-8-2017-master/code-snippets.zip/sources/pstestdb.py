import sqlite3


conn = sqlite3.connect('dec08.sqlite')
cur = conn.cursor()
# query = 'select sqlite_version()'

query = """
create table if not exists passwd (
    login varchar(32),
    passwd varchar(4),
    uid int,
    gid int,
    gecos varchar(128),
    home varchar(32),
    shell varchar(32)
)
"""

cur.execute(query)
conn.close()
