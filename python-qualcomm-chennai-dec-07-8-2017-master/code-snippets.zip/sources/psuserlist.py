def get_user_list(data_file, target_file):
    try:
        user_list = list()

        for line in open(data_file):
            login = line.split(':')[0]
            user_list.append(login.upper())

        user_list.sort()

        fw = open(target_file, 'w')

        for line_no, user in enumerate(user_list, 1):
            content = "{:>6}  {}".format(line_no, user)
            print(content)
            fw.write(content + "\n")

        fw.close()

    except (FileNotFoundError, IOError) as err:
        print(err)


get_user_list('passwd.txt')
