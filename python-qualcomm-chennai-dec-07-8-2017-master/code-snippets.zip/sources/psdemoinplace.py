"""stream editor"""

from fileinput import input, filelineno
import re

verson = '0.0.1'

def sed(pattern, *args):
    """
    abstract
    :param pattern: str
    :param args: tuple
    :return: None
    """
    for line in input(args, inplace=True, backup='.bak'):

        if re.search(pattern, line):
            line = ''
            print(line, end='')
        else:
            print(line, end='')