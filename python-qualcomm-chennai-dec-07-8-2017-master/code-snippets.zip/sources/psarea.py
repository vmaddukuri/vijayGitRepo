# string formatting
# {:fmt-str}
# pylint
"""a simple demo for the string formatting"""
from math import pi


def compute(radius):
    """
    compute, compute's
    :param radius: int, float
    :return: flolat
    """
    return pi * (radius ** 2)


try:
    user_radius = float(input('enter the radius :'))
    area = compute(user_radius)
    content = 'radius : {}\narea : {:.3f}'.format(user_radius, area)  # sprintf
    print(content.upper())
except ValueError as err:
    print(err)
