from zipfile import ZipFile
from os.path import isdir
from os import mkdir, chdir


def create_zip(zip_name, *args):
    try:
        zp = ZipFile(zip_name, mode='w')

        for file_name in args:
            zp.write(file_name)

        zp.close()
    except Exception as err:
        print(err)


def extract_zip(zip_name, target_dir='.'):
    try:
        zp = ZipFile(zip_name, mode='r')

        if target_dir != '.' :
            if not isdir(target_dir):
                mkdir(target_dir)

            chdir(target_dir)

        zp.extractall()
        zp.close()
    except Exception as err:
        print(err)
