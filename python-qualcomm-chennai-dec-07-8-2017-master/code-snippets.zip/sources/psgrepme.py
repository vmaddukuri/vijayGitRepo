import re
from fileinput import input, filelineno, filename


def grep_me(pattern, *args):
    try:
        for line in input(args):
            if re.search(pattern, line, re.I):
                content = "{}:{}:{}".format(filename(), filelineno(), line)
                print(content, end='')
    except (FileNotFoundError, IOError) as err:
        print(err)


grep_me('root', 'passwd.txt', '/etc/group')
