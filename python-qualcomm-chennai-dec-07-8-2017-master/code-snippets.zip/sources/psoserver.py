from os import listdir
from os.path import isdir, isfile, join, getsize, getmtime
from time import ctime
# path = r'c:\users\ravi'
path = '/tmp'
print(listdir(path))
print()

abs_path = path + '/'+ '+~JF3727793740078883542.tmp'
print(abs_path)

abs_path2 = join(path, '+~JF3727793740078883542.tmp')
print(abs_path2)
print()
print(isfile(abs_path2))
print(isdir(abs_path2))
print(getsize(abs_path2))
print(getmtime(abs_path2))
print(ctime(getmtime(abs_path2)))