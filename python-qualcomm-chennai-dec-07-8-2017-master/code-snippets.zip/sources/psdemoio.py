
# comment
try:
    name = input('enter the name :')
    city = input('enter the city :')
    zip_code = int(input('enter the postal zip :'))
    print(1234)
    print('name :', name, '\ncity :', city)
    print(zip_code)
    print(type(zip_code))
except ValueError as err:
    print(err)
