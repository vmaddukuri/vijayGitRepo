try:
    fp = None
    fp = open('passwd.txt')

    for line in fp:
        print(line, end='')
    
except (FileNotFoundError, IOError) as err:
    print(err)
finally:
    if fp:
        fp.close()