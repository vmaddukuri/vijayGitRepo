from json import load
from pprint import pprint as pp


content = load(open('tmp.json'))
captions = ['size', 'mtime']

for dir_name, dir_items in content.items():
    print(dir_name)

    for file_name, file_prop in dir_items.items():
        print("\t", file_name)

        for title, value in zip(captions, file_prop):
            print("\t\t", title, ':', value)
    print()