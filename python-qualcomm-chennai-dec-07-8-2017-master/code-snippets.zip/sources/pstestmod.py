from psdemoinplace import sed
sed(r'\b([5-9]\d\d)|[1-9]\d{3,}\b', 'passwd.txt')


