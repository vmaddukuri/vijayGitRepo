from csv import reader
from pprint import pprint as pp
import sqlite3


def csv2db(csv_file):
    conn = sqlite3.connect('dec08.sqlite')
    cursor = conn.cursor()
    # query = 'select sqlit
    content = csv_parser(csv_file)
    query = "insert into passwd values(?, ?, ?, ?, ?, ?, ?)"
    cursor.executemany(query, content)
    conn.commit()
    conn.close()


def csv_parser(csv_file):
    try:
        return [record for record in reader(open(csv_file), delimiter=':')]

    except(FileNotFoundError, IOError) as err:
        print(err)


csv2db('passwd.txt')
