print('kim', end='')  # keyword argument parameter
print('amanda', end='')
print('sam', end='')  # ORS
print('tim', end='')
print('tom')
print(1,2,'iii',4.4,5.0)
print(1,2,'iii',4.4,5.0, sep=':') # OFS