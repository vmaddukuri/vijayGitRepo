n = 10  # globAL


def demo():
    n = 'pip'  # local
    print(globals()['n'])
    print(n)

demo()
print(n)