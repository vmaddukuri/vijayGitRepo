name, age, gender = 'sarah', 4.4, 'female'  # parallel assignment

a = [1, 2, 3, 4]
print("|{}|{}|{}|".format(name, age, gender))
print("|{:>22}|{:>9}|{:>16}|".format(name, age, gender))
print("|{:<22}|{:<9}|{:<16}|".format(name, age, gender))
print("|{:^22}|{:^9}|{:^16}|".format(name, age, gender))
print("|{:22}|{:9}|{:16}|".format(name, age, gender))  # default justify
print("|{:22}|{:9f}|{:16}|".format(name, age, gender))
# print(a[-2])

f = None
print(type(f))

def demo():
    print(1234)

print(demo())