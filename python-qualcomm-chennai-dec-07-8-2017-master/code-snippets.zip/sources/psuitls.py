from os import listdir
from os.path import isfile, join, getsize, getmtime, basename
from time import ctime
from pprint import pprint as pp
from json import dump


def directory_listing(*args):  # variable len argument
    """a directory listing function"""
    container = dict()

    for dir_name in args:
        file_names = [join(dir_name, item) for item in listdir(dir_name) if isfile(join(dir_name, item))]
        temp = dict()

        for file_name in file_names:
            file_properties = [getsize(file_name), ctime(getmtime(file_name))]
            file_name = basename(file_name)
            temp[file_name] = file_properties

        container[dir_name] = temp

    return container


def to_json(py_data, json_file):
    """
    to_json, serializes the python object into json & writes into the given file
    :param py_data:
    :param json_file: str
    :return: None
    """
    try:
        dump(py_data, open(json_file, 'w'), indent=4)
    except (FileNotFoundError, IOError) as err:
        print(err)


dl = directory_listing('/tmp', '/home/ravi')
to_json(dl, 'tmp.json')
